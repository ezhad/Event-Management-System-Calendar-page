import 'dart:html';
import 'selectedDay.dart';

void main() {
  var days = querySelector('#days');
}
